<?php
// HTTP
define('HTTP_SERVER', 'http://opt-kamorka.ru/admin/');
define('HTTP_CATALOG', 'http://opt-kamorka.ru/');

// HTTPS
define('HTTPS_SERVER', 'http://opt-kamorka.ru/admin/');
define('HTTPS_CATALOG', 'http://opt-kamorka.ru/');

// DIR
define('DIR_APPLICATION', 'W:/domains/opt-kamorka.ru/admin/');
define('DIR_SYSTEM', 'W:/domains/opt-kamorka.ru/system/');
define('DIR_IMAGE', 'W:/domains/opt-kamorka.ru/image/');
define('DIR_LANGUAGE', 'W:/domains/opt-kamorka.ru/admin/language/');
define('DIR_TEMPLATE', 'W:/domains/opt-kamorka.ru/admin/view/template/');
define('DIR_CONFIG', 'W:/domains/opt-kamorka.ru/system/config/');
define('DIR_CACHE', 'W:/domains/opt-kamorka.ru/system/storage/cache/');
define('DIR_DOWNLOAD', 'W:/domains/opt-kamorka.ru/system/storage/download/');
define('DIR_LOGS', 'W:/domains/opt-kamorka.ru/system/storage/logs/');
define('DIR_MODIFICATION', 'W:/domains/opt-kamorka.ru/system/storage/modification/');
define('DIR_UPLOAD', 'W:/domains/opt-kamorka.ru/system/storage/upload/');
define('DIR_CATALOG', 'W:/domains/opt-kamorka.ru/catalog/');

// DB
define('DB_DRIVER', 'mysqli');
define('DB_HOSTNAME', 'localhost');
define('DB_USERNAME', 'FujiQwer');
define('DB_PASSWORD', 'papacloud3286');
define('DB_DATABASE', 'fujiqwer');
define('DB_PORT', '3306');
define('DB_PREFIX', 'oc_');
